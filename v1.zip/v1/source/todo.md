# ToDo

- Markere celler grønn/rød hvis de er langt unna snittet for den raden
- Ta i bruk
  - npm helmet: https://github.com/helmetjs/helmet
  - npm cors

## Større issues

- Ta inn inntekt / beløp over 0

# Done

- Fikse bug med utenlandsk valuta
    - Lese rett fra excel
